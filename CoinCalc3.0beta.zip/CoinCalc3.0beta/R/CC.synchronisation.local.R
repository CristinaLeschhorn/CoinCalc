# Autor: Leonna Szangolies, Potsdam Institute for Climate Impact Research, 2020
# This function is part of the R package CoinCalc3.0().
# CC.synchronisation.local performes event synchronisation with local tau including a shuffle significance tests using time series and some parameters.

CC.synchronisation.local<-function(a,b,sigtest=TRUE,reps=1000,alpha=0.05){
  if (length(table(a)) > 2) {
    print("|-------------    ERROR #1    -------------|")
    print("|       Time seriesA is not binary         |")
    print("|      (or the number of events=0)!        |")
    print("| Use CC.binarize() to preprocess seriesA  |")
    print("|------------------------------------------|")
    return()
  }
  if (length(table(b)) > 2) {
    print("|-------------    ERROR #1    -------------|")
    print("|       Time seriesB is not binary         |")
    print("|      (or the number of events=0)!        |")
    print("| Use CC.binarize() to preprocess seriesB  |")
    print("|------------------------------------------|")
    return()
  }
  ta<-which(a==1)
  tb<-which(b==1)
  
  tau=matrix(nrow=length(ta),ncol=length(tb))
  
  sum_ab=0
  for(i in 1:length(ta)){
    for(j in 1:length(tb)){
      tau[i,j]=min(ta[i+1]-ta[i],ta[i]-ta[i-1],tb[j+1]-tb[j],tb[j]-tb[j-1],na.rm=TRUE)/2
      if(0<(ta[i]-tb[j]) && (ta[i]-tb[j])<=tau[i,j]){
        sum_ab=sum_ab+1
      }else{
        if(ta[i]==tb[j]){
          sum_ab=sum_ab+0.5
        }
      }
    }
  }
  sum_ba=0
  for(i in 1:length(tb)){
    for(j in 1:length(ta)){
      if(0<(tb[i]-ta[j]) && (tb[i]-ta[j])<=tau[j,i]){
        sum_ba=sum_ba+1
      }else{
        if(tb[i]==ta[j]){
          sum_ba=sum_ba+0.5
        }
      }
    }
  }
  Q=(sum_ba+sum_ab)/sqrt(length(ta)*length(tb)) #Q=1 -> fully synchronized
  q=(sum_ba-sum_ab)/sqrt(length(ta)*length(tb)) #q=1 -> x events always precede y events
  
  
  if (sigtest == TRUE) {#shuffle test
    surdist = matrix(NA, 2, reps)
    span = seq(1:length(a))
    for (surno in 1:reps) {
      surA = sample(span, size = length(ta))
      surB = sample(span, size = length(tb))
      K_Q_sur = 0
      K_q_sur = 0
      for (step_b in 1:length(tb)) {
        new1=(0.5*sum((surB[step_b]  - surA)>0 && (surB[step_b]  - surA)<tau[,step_b])+sum((surB[step_b]-surA)==0))
        K_Q_sur=K_Q_sur+new1
        K_q_sur=K_q_sur+new1
      }
      for (step_a in 1:length(ta)) {
        new2=(0.5*sum((surA[step_a]  - surB)>0 && (surA[step_a]  - surB)<tau[step_a,])+sum((surA[step_a]-surB)==0))
        K_Q_sur=K_Q_sur+new2
        K_q_sur=K_q_sur-new2
      }
      surdist[1, surno] = (K_Q_sur/sqrt(length(ta)*length(tb)))
      surdist[2, surno] = (K_q_sur/sqrt(length(ta)*length(tb)))
    }
    PQ = 1 - ecdf(surdist[1, ])(Q)
    Pq = 1 - ecdf(surdist[2, ])(q)
    
    sig_testQ = logical
    if (PQ >= alpha) {
      sig_testQ = TRUE
    }
    else {
      sig_testQ = FALSE
    }
    sig_testq = logical
    if (Pq >= alpha) {
      sig_testq = TRUE
    }
    else {
      sig_testq = FALSE
    }
    CA_out = list(sig_testQ, sig_testq, PQ, Pq, 
                  Q, q)
    names(CA_out) = c("NH Q", "NH q", "p-value Q", 
                      "p-value q", "Q", "q")
  }else{
    CA_out = list(Q, q)
    names(CA_out) = c("Q", "q")
  }
  return(CA_out)
}