# Author: Leonna Szangolies, Jonatan Siegmund, Potsdam Institute for Climate Impact Research, 2020
# This function is part of the R package CoinCalc3.0().
# CC.eca.es performes event coincidence analysis including three different significance tests using event time series and some parameters.

CC.eca.es <- function(seriesA,seriesB,spanA,spanB,delT,alpha=0.05,sym=FALSE,tau=0,sigtest="poisson",reps=1000){ 
    # ----------------------------------------------- TEST FOR ERRORS IN FUNCTION CALL  ------------------------------------------------------------------------------  
    # ---- #1: delT or tau negative
    if(tau<0 || delT<0){
        print("|-------------    ERROR #1    -------------|")
        print("|    The offset (tau) or delta T (delT)    |")
        print("|              is negative.                |") 
        print("|------------------------------------------|")
        return()}
    # ---- #2: seriesA is not a vector
    if(!is.vector(seriesA)){
        print("|-------------    ERROR #2    -------------|")
        print("|         series A is not a vector         |")
        print("|------------------------------------------|")
        return()}
    # ---- #3: seriesB is not a vector
    if(!is.vector(seriesB)){
        print("|-------------    ERROR #3    -------------|")
        print("|         series B is not a vector         |")
        print("|------------------------------------------|")
        return()}
    # ---- #4: time spans do not match
    if(spanA[1]>spanB[2] || spanB[1]>spanA[2]){
        print("|-------------    ERROR #4    -------------|")
        print("|         no common time span found        |")
        print("|          for spanA and spanB             |")       
        print("|------------------------------------------|")
        return()} 
    # ---- #6: list format
    if(is.list(seriesA)|| is.list(seriesB)){
        print("|-------------    ERROR #6    -------------|")
        print("|  seriesA or seriesB seems to be a list   |")
        print("|          but has to be a vector          |")       
        print("|------------------------------------------|")
        return()} 

    #-------Turn into timeseries and use CC.eca.ts
    seriesA<-CC.es2ts(seriesA,spanA)
    seriesB<-CC.es2ts(seriesB,spanB)
    CC.eca.ts(seriesA,seriesB,alpha = alpha, delT = delT, sym = sym, tau = tau, sigtest = sigtest, reps = reps)
}